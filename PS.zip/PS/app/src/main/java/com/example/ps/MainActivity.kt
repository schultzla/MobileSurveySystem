package com.example.ps

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {

    private var loginBt: Button? = null
    private var registerBt: Button? = null
    private var startBt: Button? = null
    private var code:EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        loginBt = findViewById<Button>(R.id.login)
        registerBt = findViewById<Button>(R.id.register)
        startBt = findViewById<Button>(R.id.start)
        code = findViewById<EditText>(R.id.code)

        code!!.inputType = InputType.TYPE_CLASS_NUMBER

        loginBt!!.setOnClickListener {
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }
        registerBt!!.setOnClickListener {
            val intent = Intent(this, Register::class.java)
            startActivity(intent)
        }
        startBt!!.setOnClickListener {
            //To the survey
        }
    }
}