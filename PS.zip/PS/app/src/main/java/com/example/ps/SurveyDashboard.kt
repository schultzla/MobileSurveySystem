package com.example.ps

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class SurveyDashboard  : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.survey_dashboard)
    }
}